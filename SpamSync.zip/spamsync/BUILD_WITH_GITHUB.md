# Get your .geode file without installing anything

1. Make a free GitHub account and create a new repository (any name, public or private).
2. Click "uploading an existing file" and drag in EVERYTHING from this folder, including the hidden `.github` folder. If your browser or file manager hides it, turn on "show hidden files" first.
3. Edit `mod.json` and change `id` and `developer` (for example `yourname.spamsync`).
4. Commit. Open the repo's **Actions** tab. A "Build Geode Mod" run starts by itself and takes a few minutes.
5. When it finishes, open the run and download **Build Output** at the bottom. Unzip it to get the `.geode` file.
6. Put the `.geode` file in your Geometry Dash `geode/mods` folder and restart the game.

If a platform fails (red X), open it and copy the error text. Send it to Claude to fix.
You only need the platform you play on to pass.
