# SPAMSYNC
**PRECISION RHYTHM TOOLS**

| Feature | Status |
|---|---|
| Alt-Spam timing analysis | READY |
| Single-Key consistency analysis | READY |
| Hybrid mode / correction | EXPERIMENTAL (written, untested in-game) |

## What it does
- Live HUD (top-left): CPS, consistency %, mean interval, standard deviation, A/B skew.
- Counts every jump press, including custom jump bindings (they all reach `GJBaseGameLayer::handleButton`).
- **Hybrid (Experimental):** learns your average press interval during a burst. If a press arrives earlier than that rhythm, it is held back a few milliseconds. Late presses are never touched. Releases are shifted equally, so hold length and order are preserved.

## Settings
- Mode: Alt-Spam / Single-Key / Hybrid (Experimental)
- Correction Strength (0-100) and Max Delay (1-40 ms)
- **Correction: Practice Mode Only** (default ON): correction never runs in normal attempts
- HUD visibility and opacity, analysis window size

## Honest limits
- Not compiled or tested in-game yet. Expect small compile errors on the first build.
- Correction can only delay presses, never speed them up, so it tends to nudge your effective CPS slightly down.
- Delays are quantised to your frame rate.
- The mod can't tell which physical key was pressed, so you choose the mode yourself.
- Correction changes your inputs. If you turn "Practice Mode Only" off, don't use it for runs you plan to submit as legit.

## Build
See `BUILD_WITH_GITHUB.md` (no installs needed), or locally with the Geode CLI: `geode build`.
Change `id` and `developer` in `mod.json` first.
Targets Geometry Dash 2.2081 and Geode 5.x.
