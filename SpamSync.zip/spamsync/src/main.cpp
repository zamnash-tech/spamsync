// SpamSync — Precision Rhythm Tools
// Alt-Spam analysis:       READY
// Single-Key analysis:     READY
// Hybrid correction:       EXPERIMENTAL (written, not yet tested in-game)

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <deque>
#include <optional>
#include <string>
#include <vector>

using namespace geode::prelude;

namespace spamsync {
    using Clock = std::chrono::steady_clock;
    using TimePoint = Clock::time_point;
    using Ms = std::chrono::duration<double, std::milli>;

    inline Clock::duration toDuration(double ms) {
        return std::chrono::duration_cast<Clock::duration>(Ms(ms));
    }

    inline constexpr const char* HYBRID_MODE = "Hybrid (Experimental)";

    // ------------------------------------------------------------------
    // Analysis
    // ------------------------------------------------------------------
    struct Stats {
        size_t samples = 0;       // intervals in the current burst
        double cps = 0.0;
        double meanMs = 0.0;
        double stdDevMs = 0.0;
        double consistency = 0.0; // 0-100
        double altSkewMs = 0.0;   // |mean(even) - mean(odd)| intervals
    };

    class Analyzer {
    public:
        static Analyzer& get() {
            static Analyzer inst;
            return inst;
        }

        void reset() { m_presses.clear(); }

        void record(TimePoint t) {
            m_presses.push_back(t);
            size_t cap = static_cast<size_t>(
                Mod::get()->getSettingValue<int64_t>("window-size")
            ) + 1;
            while (m_presses.size() > cap) m_presses.pop_front();
        }

        Stats compute() const {
            Stats s;
            if (m_presses.size() < 3) return s;

            auto now = Clock::now();
            if (Ms(now - m_presses.back()).count() > 1000.0) return s; // burst is over

            // Walk backwards from the newest press; stop at a pause (>400 ms gap).
            std::vector<double> iv; // newest first
            for (size_t i = m_presses.size() - 1; i > 0; --i) {
                double d = Ms(m_presses[i] - m_presses[i - 1]).count();
                if (d > 400.0) break;
                iv.push_back(d);
            }
            if (iv.size() < 2) return s;
            std::reverse(iv.begin(), iv.end()); // oldest first

            double sum = 0.0;
            for (double d : iv) sum += d;
            double mean = sum / iv.size();

            double var = 0.0;
            for (double d : iv) var += (d - mean) * (d - mean);
            var /= iv.size();
            double sd = std::sqrt(var);

            s.samples = iv.size();
            s.meanMs = mean;
            s.stdDevMs = sd;
            s.cps = mean > 0.0 ? 1000.0 / mean : 0.0;
            s.consistency = mean > 0.0
                ? std::clamp(100.0 * (1.0 - sd / mean), 0.0, 100.0)
                : 0.0;

            if (iv.size() >= 4) {
                double e = 0.0, o = 0.0;
                size_t ne = 0, no = 0;
                for (size_t i = 0; i < iv.size(); ++i) {
                    if (i % 2 == 0) { e += iv[i]; ++ne; }
                    else            { o += iv[i]; ++no; }
                }
                s.altSkewMs = std::abs(e / ne - o / no);
            }
            return s;
        }

    private:
        std::deque<TimePoint> m_presses;
    };

    // ------------------------------------------------------------------
    // Hybrid correction (EXPERIMENTAL)
    //
    // Learns your average press interval during a burst. When a press
    // arrives EARLIER than that rhythm predicts, it is held back a few
    // milliseconds so the delivered rhythm is more even. Presses that
    // arrive late are never touched (a press cannot be sent early).
    // Releases are shifted by the same amount so hold lengths are kept
    // and press/release order never changes.
    //
    // Limits: delays are quantised to your frame rate, capped by
    // "correction-max-delay", and scaled by "correction-strength".
    // ------------------------------------------------------------------
    struct PendingEvent {
        bool down;
        int button;
        bool isPlayer1;
        TimePoint fireAt;
    };

    class Corrector {
    public:
        static Corrector& get() {
            static Corrector inst;
            return inst;
        }

        void reset() {
            m_queue.clear();
            m_hasEma = false;
            m_ema = 0.0;
            m_samples = 0;
            m_lastRaw.reset();
            m_lastDelivered.reset();
            m_lastShiftMs = 0.0;
            m_lastAppliedMs = 0.0;
        }

        bool empty() const { return m_queue.empty(); }
        double lastAppliedMs() const { return m_lastAppliedMs; }

        // Returns true if the event was queued; the caller must then NOT
        // deliver it now. Returns false if it should go through unchanged.
        bool intercept(bool down, int button, bool isPlayer1, TimePoint now,
                       double strengthPct, double maxDelayMs) {
            if (down && button == 1) {
                // Update the rhythm model from the player's raw timing.
                if (m_lastRaw) {
                    double raw = Ms(now - *m_lastRaw).count();
                    if (raw <= 400.0) {
                        m_ema = m_hasEma ? 0.8 * m_ema + 0.2 * raw : raw;
                        m_hasEma = true;
                        ++m_samples;
                    } else {
                        m_hasEma = false;
                        m_samples = 0;
                    }
                }
                m_lastRaw = now;

                double shift = 0.0;
                if (m_hasEma && m_samples >= 4 && m_lastDelivered) {
                    auto target = *m_lastDelivered + toDuration(m_ema);
                    double delay = Ms(target - now).count();
                    if (delay > 0.0) {
                        shift = std::min(delay * strengthPct / 100.0, maxDelayMs);
                    }
                }

                auto fireAt = now + toDuration(shift);
                if (!m_queue.empty() && fireAt < m_queue.back().fireAt) {
                    fireAt = m_queue.back().fireAt; // keep order
                }

                m_lastShiftMs = Ms(fireAt - now).count();
                m_lastAppliedMs = m_lastShiftMs;
                m_lastDelivered = fireAt;

                if (m_queue.empty() && m_lastShiftMs <= 0.0) return false;
                m_queue.push_back({down, button, isPlayer1, fireAt});
                return true;
            }

            // Releases and other buttons: only queue if something is pending,
            // so they stay in order behind the delayed press.
            if (m_queue.empty()) return false;
            auto fireAt = std::max(now + toDuration(m_lastShiftMs), m_queue.back().fireAt);
            m_queue.push_back({down, button, isPlayer1, fireAt});
            return true;
        }

        template <class F>
        void flush(TimePoint now, F&& deliver) {
            while (!m_queue.empty() && m_queue.front().fireAt <= now) {
                PendingEvent e = m_queue.front();
                m_queue.pop_front();
                deliver(e);
            }
        }

    private:
        std::deque<PendingEvent> m_queue;
        bool m_hasEma = false;
        double m_ema = 0.0;
        size_t m_samples = 0;
        std::optional<TimePoint> m_lastRaw;
        std::optional<TimePoint> m_lastDelivered;
        double m_lastShiftMs = 0.0;
        double m_lastAppliedMs = 0.0;
    };

    inline bool correctionActive(bool inPractice) {
        auto mod = Mod::get();
        if (!mod->getSettingValue<bool>("enabled")) return false;
        if (mod->getSettingValue<std::string>("mode") != HYBRID_MODE) return false;
        if (mod->getSettingValue<bool>("practice-only") && !inPractice) return false;
        return mod->getSettingValue<double>("correction-strength") > 0.0;
    }
}

// Every jump binding (default or custom) ends up in handleButton,
// so custom jump bindings are handled without extra setup.
class $modify(SSBaseGameLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        auto mod = Mod::get();
        auto now = spamsync::Clock::now();

        if (down && button == 1 && mod->getSettingValue<bool>("enabled")) {
            spamsync::Analyzer::get().record(now); // always records the RAW press
        }

        if (spamsync::correctionActive(m_isPracticeMode)) {
            double strength = mod->getSettingValue<double>("correction-strength");
            double maxDelay = static_cast<double>(
                mod->getSettingValue<int64_t>("correction-max-delay")
            );
            if (spamsync::Corrector::get().intercept(down, button, isPlayer1, now, strength, maxDelay)) {
                return;
            }
        }

        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }

    void update(float dt) {
        auto& corrector = spamsync::Corrector::get();
        if (!corrector.empty()) {
            corrector.flush(spamsync::Clock::now(), [this](spamsync::PendingEvent const& e) {
                GJBaseGameLayer::handleButton(e.down, e.button, e.isPlayer1);
            });
        }
        GJBaseGameLayer::update(dt);
    }
};

class $modify(SSPlayLayer, PlayLayer) {
    struct Fields {
        CCLabelBMFont* title = nullptr;
        CCLabelBMFont* tagline = nullptr;
        CCLabelBMFont* body = nullptr;
    };

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;

        spamsync::Analyzer::get().reset();
        spamsync::Corrector::get().reset();

        auto win = CCDirector::get()->getWinSize();
        auto f = m_fields.self();

        f->title = CCLabelBMFont::create("SPAMSYNC", "bigFont.fnt");
        f->title->setAnchorPoint({0.f, 1.f});
        f->title->setScale(0.35f);
        f->title->setPosition({10.f, win.height - 8.f});
        f->title->setID("title"_spr);

        f->tagline = CCLabelBMFont::create("PRECISION RHYTHM TOOLS", "chatFont.fnt");
        f->tagline->setAnchorPoint({0.f, 1.f});
        f->tagline->setScale(0.4f);
        f->tagline->setPosition({10.f, win.height - 24.f});
        f->tagline->setColor({150, 160, 175});
        f->tagline->setID("tagline"_spr);

        f->body = CCLabelBMFont::create("", "chatFont.fnt");
        f->body->setAnchorPoint({0.f, 1.f});
        f->body->setScale(0.6f);
        f->body->setPosition({10.f, win.height - 38.f});
        f->body->setID("stats"_spr);

        m_uiLayer->addChild(f->title, 100);
        m_uiLayer->addChild(f->tagline, 100);
        m_uiLayer->addChild(f->body, 100);
        return true;
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        spamsync::Corrector::get().reset();
    }

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);

        auto f = m_fields.self();
        if (!f->body) return;

        auto mod = Mod::get();
        bool visible = mod->getSettingValue<bool>("enabled")
                    && mod->getSettingValue<bool>("show-hud");
        f->title->setVisible(visible);
        f->tagline->setVisible(visible);
        f->body->setVisible(visible);
        if (!visible) return;

        auto opacity = static_cast<GLubyte>(mod->getSettingValue<int64_t>("hud-opacity"));
        f->title->setOpacity(opacity);
        f->tagline->setOpacity(opacity);
        f->body->setOpacity(opacity);

        auto mode = mod->getSettingValue<std::string>("mode");
        auto s = spamsync::Analyzer::get().compute();

        std::string header;
        if (mode == "Alt-Spam") header = "ALT-SPAM  READY";
        else if (mode == "Single-Key") header = "SINGLE-KEY  READY";
        else header = "HYBRID MODE  EXPERIMENTAL";

        std::string text = header;
        if (s.samples == 0) {
            text += "\nWaiting for input...";
        } else {
            text += fmt::format(
                "\nCPS {:.1f}\nCONSISTENCY {:.0f}%\nINTERVAL {:.1f} ms (SD {:.1f})",
                s.cps, s.consistency, s.meanMs, s.stdDevMs
            );
            if (mode != "Single-Key") {
                text += fmt::format("\nA/B SKEW {:.1f} ms", s.altSkewMs);
            }
        }

        if (mode == spamsync::HYBRID_MODE) {
            if (spamsync::correctionActive(m_isPracticeMode)) {
                text += fmt::format(
                    "\nCORRECTION ON  +{:.1f} ms",
                    spamsync::Corrector::get().lastAppliedMs()
                );
            } else if (mod->getSettingValue<bool>("practice-only") && !m_isPracticeMode) {
                text += "\nCORRECTION OFF  (PRACTICE ONLY)";
            } else {
                text += "\nCORRECTION OFF";
            }
        }

        f->body->setString(text.c_str());
    }
};
